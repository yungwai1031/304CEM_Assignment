//logic for index page
const productModel = require('../model/mongoose/model/productModel')

// index page
exports.index = function (req, res) {
  productModel.findAll(function (err, products) {
    res.render('index', {
      title: 'Home Page',
      products: products
    })
  })
}
