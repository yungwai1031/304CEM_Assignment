//logic for product
const productModel = require('../model/mongoose/model/productModel')
const _ = require('underscore')

//get detailed page
exports.detail = function (req, res) {
  let id = req.params.id
  productModel.findById(id, function (err, product) {
    res.render('detail', {
      title: 'Product Detail Information',
      product: product
    })
  })
}

//get product page
exports.newProduct = function (req, res) {
  res.render('newProduct', {
    title: 'Add Product',
    product: {
      title: '',
      price: '',
      inventory: '',
      photo: '',
      summary: ''
    }
  })
}

//add product
exports.productSave = function (req, res) {
  let id = req.body.product._id
  let productObj = req.body.product
  let postProduct = null

  //if id exist,then update else create
  console.log(id)
  if (id) {
    productModel.findById(id, function (err, product) {
      postProduct = _.extend(product, productObj)
      postProduct.save(function (err, product) {
        res.redirect('/detail/' + product._id)
      })
    })
  } else {
    postProduct = new productModel({
      title: productObj.title,
      price: productObj.price,
      inventory: productObj.inventory,
      photo: productObj.photo,
      summary: productObj.summary
    })

    postProduct.save(function (err, product) {
      if (err) {
        console.log(err)
      }
      console.log('test')
      res.redirect('/detail/' + product._id)
    })
  }
}

//get product
exports.getProductList = function (req, res) {
  productModel.findAll(function (err, products) {
    res.render('getProductList', {
      title: 'Admin Page for Product',
      products: products
    })
  })
}

//update product
exports.productUpdate = function (req, res) {
  let id = req.params.id

  if (id) {
    productModel.findById(id, function (req, product) {
      res.render('newProduct', {
        title: 'Update Product Information',
        product: product
      })
    })
  }
}

//delete product
exports.productDelete = function (req, res) {
  let id = req.query.id
  if (id) {
    productModel.remove({ _id: id }, function (err, product) {
      if (!err) {
        res.json({ success: 1 })
      }
    })
  }
}
