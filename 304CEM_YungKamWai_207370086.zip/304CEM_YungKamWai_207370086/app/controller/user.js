//logic for user
const userModel = require('../model/mongoose/model/userModel')
const _ = require('underscore')

//check whether session is existed or not
exports.userRequestLogin = function (req, res, next) {
  let user = req.session.user
  if (!user) {
    return res.redirect('/userLogin')
  }
  next()
}

//register page
exports.showRegisterPage = function (req, res) {
  res.render('userRegister', {
    title: 'Register Page'
  })
}

//login page
exports.showLoginPage = function (req, res) {
  res.render('userLogin', {
    title: 'Login Page'
  })
}

//check if user exist when register
exports.userRegister = function (req, res) {
  let userObj = req.body.user
  userModel.findOne({ name: userObj.name }, function (err, user) {
    if (user) {
      //user existed
      return res.redirect('/userRegister')
    } else {
      let newUser = new userModel(userObj)
      newUser.save(function (err, user) {
        res.redirect('/userLogin')
      })
    }
  })
}

//check login
exports.userLogin = function (req, res) {
  let userObj = req.body.user
  let name = userObj.name
  let password = userObj.password

  // check in db
  userModel.findOne({ name: name }, function (err, result) {
    if (!result) {
      //not exist
      return res.redirect('/userLogin')
    }

    result.comparePassword(password, function (err, isMatch) {
      if (isMatch) {
        // store the session
        req.session.user = result
        return res.redirect('/')
      } else {
        // request login again
        return res.redirect('/userLogin')
      }
    })
  })
}

//logout
exports.userLogout = function (req, res) {
  delete req.session.user
  res.redirect('/')
}
