//logic for category
const categoryModel = require('../model/mongoose/model/categoryModel')

exports.newCategory = function (req, res) {
  res.render('newCategory', {
    title: 'Add New Category',
    category: {
      name: ''
    }
  })
}

exports.saveCategory = function (req, res) {
  let _category = req.body.category
  let category = new categoryModel(_category)

  category.save(function (err, category) {
    res.redirect('/admin/getCategoryLst')
  })
}

exports.getCategoryLst = function (req, res) {
  categoryModel.findAll(function (err, allCategories) {
    res.render('getCategoryLst', {
      title: 'Category List',
      categorys: allCategories
    })
  })
}

//delete category
exports.deleteCategory = function (req, res) {
  let id = req.query.id
  if (id) {
    categoryModel.remove({ _id: id }, function (err, category) {
      if (!err) {
        res.json({ success: 1 })
      }
    })
  }
}
