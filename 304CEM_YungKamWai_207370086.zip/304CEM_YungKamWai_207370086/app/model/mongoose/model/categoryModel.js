let mongoose = require('mongoose')
let categorySchema = require('../schema/categorySchema')
let categoryModel = mongoose.model('category', categorySchema)

module.exports = categoryModel
