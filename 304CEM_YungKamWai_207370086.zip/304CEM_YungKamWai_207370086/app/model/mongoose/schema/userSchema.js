//user model
const mongoose = require('mongoose')
const bcryptjs = require('bcryptjs')
//bcrypt
const SALT_WORK_FACTOR = 10
//define schema model for user
let userSchema = new mongoose.Schema({
  name: {
    type: String,
    unique: true
  },
  password: {
    type: String
  },
  role: {
    type: Number,
    default: 100
  },
  meta: {
    createAt: {
      type: Date,
      default: Date.now()
    },
    updateAt: {
      type: Date,
      default: Date.now()
    }
  }
})
//save method
userSchema.pre('save', function (next) {
  let user = this

  if (this.isNew) {
    this.meta.createdAt = Date.now()
    this.meta.updateAt = Date.now()
  } else {
    this.meta.updateAt = Date.now()
  }
  //encrypt the password
  bcryptjs.genSalt(SALT_WORK_FACTOR, function (err, salt) {
    if (err) {
      return next(err)
    }
    bcryptjs.hash(user.password, salt, function (err, hash) {
      if (err) {
        return next(err)
      }
      user.password = hash
      next()
    })
  })
})
//get user
userSchema.statics = {
  findAll: function (cb) {
    return this.find({}).sort('meta.createAt').exec(cb)
  },
  findById: function (id, cb) {
    return this.findOne({ _id: id }).exec(cb)
  }
}
//check login
userSchema.methods = {
  comparePassword: function (password, cb) {
    //check password
    bcryptjs.compare(password, this.password, function (err, isMatch) {
      cb(null, isMatch)
    })
  }
}

module.exports = userSchema
