//Category model
const mongoose = require('mongoose')
let ObjectId = mongoose.Schema.Types.ObjectId
//define schema model for category
let categorySchema = new mongoose.Schema({
  name: {
    type: String
  },
  product: [
    {
      type: ObjectId,
      ref: 'productModel'
    }
  ],
  meta: {
    createAt: {
      type: Date,
      default: Date.now()
    },
    updateAt: {
      type: Date,
      default: Date.now()
    }
  }
})
//save category
categorySchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = Date.now()
    this.meta.updateAt = Date.now()
  } else {
    this.meta.updateAt = Date.now()
  }

  next()
})
//get category
categorySchema.statics = {
  findAll: function (cb) {
    return this.find({}).sort('meta.createAt').exec(cb)
  },
  findById: function (id, cb) {
    return this.findOne({ _id: id }).exec(cb)
  }
}

module.exports = categorySchema
