//product category
const mongoose = require('mongoose')
let ObjectId = mongoose.Schema.Types.ObjectId
//define the schema for the product
let productSchema = new mongoose.Schema({
  title: String,
  price: String,
  inventory: Number,
  photo: String,
  summary: String,
  category: {
    type: ObjectId,
    ref: 'categoryModel'
  },
  meta: {
    createAt: {
      type: Date,
      default: Date.now()
    },
    updateAt: {
      type: Date,
      default: Date.now()
    }
  }
})
//save methhod
productSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = Date.now()
    this.meta.updateAt = Date.now()
  } else {
    this.meta.updateAt = Date.now()
  }
  next()
})
//get product
productSchema.statics = {
  findAll: function (cb) {
    return this.find({}).sort('meta.createAt').exec(cb)
  },
  findById: function (id, cb) {
    return this.findOne({ _id: id }).exec(cb)
  }
}

module.exports = productSchema
