const indexController = require('../app/controller/index')
const productController = require('../app/controller/product')
const userController = require('../app/controller/user')
const categoryController = require('../app/controller/category')

module.exports = function (app) {
  app.use(function (req, res, next) {
    res.locals.user = req.session.user
    next()
  })

  //index
  app.get('/', indexController.index)

  //product && require user login
  app.get('/detail/:id', productController.detail)
  app.get('/admin/newProduct', userController.userRequestLogin, productController.newProduct)
  app.post('/admin/productSave', userController.userRequestLogin, productController.productSave)
  app.get('/admin/getProductList', userController.userRequestLogin, productController.getProductList)
  app.get('/admin/productUpdate/:id', userController.userRequestLogin, productController.productUpdate)
  app.delete('/admin/getProductList', userController.userRequestLogin, productController.productDelete)

  //category && require user login
  app.get('/admin/newCategory', userController.userRequestLogin, categoryController.newCategory)
  app.post('/admin/saveCategory', userController.userRequestLogin, categoryController.saveCategory)
  app.get('/admin/getCategoryLst', userController.userRequestLogin, categoryController.getCategoryLst)
  app.delete('/admin/getCategoryLst', userController.userRequestLogin, categoryController.deleteCategory)

  //user
  app.get('/userRegister', userController.showRegisterPage)
  app.get('/userLogin', userController.showLoginPage)
  app.post('/user/userRegister', userController.userRegister)
  app.post('/user/userLogin', userController.userLogin)
  app.get('/userLogout', userController.userLogout)
}
